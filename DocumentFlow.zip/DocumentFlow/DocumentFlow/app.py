from flask import Flask, render_template, redirect, url_for, request, flash, send_from_directory
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta, date
import os

from config import Config
from models import db, User, Document, ApprovalStage, Comment, Notification
from forms import LoginForm, DocumentForm, CommentForm

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Пожалуйста, войдите в систему'
login_manager.login_message_category = 'warning'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


@app.context_processor
def utility_processor():
    def get_notifications_count():
        if current_user.is_authenticated:
            return Notification.query.filter_by(
                recipient_id=current_user.id,
                is_read=False
            ).count()
        return 0

    return {
        'now': datetime.now,
        'notifications_count': get_notifications_count
    }


@app.route('/')
@login_required
def index():
    total_docs = Document.query.count()
    draft_docs = Document.query.filter_by(status='Черновик').count()
    pending_docs = Document.query.filter_by(status='На согласовании').count()
    approved_docs = Document.query.filter_by(status='Согласован').count()

    recent_docs = Document.query.filter_by(created_by=current_user.id)\
        .order_by(Document.created_at.desc()).limit(5).all()

    notifications = Notification.query.filter_by(
        recipient_id=current_user.id,
        is_read=False
    ).order_by(Notification.created_at.desc()).limit(5).all()

    return render_template('dashboard.html',
                           total_docs=total_docs,
                           draft_docs=draft_docs,
                           pending_docs=pending_docs,
                           approved_docs=approved_docs,
                           recent_docs=recent_docs,
                           notifications=notifications)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=form.remember.data)
            flash('Добро пожаловать!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'danger')

    return render_template('login.html', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))


@app.route('/documents')
@login_required
def documents_list():
    status_filter = request.args.get('status', 'all')
    type_filter = request.args.get('type', 'all')

    query = Document.query

    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    if type_filter != 'all':
        query = query.filter_by(doc_type=type_filter)

    documents = query.order_by(Document.created_at.desc()).all()

    return render_template('documents/list.html',
                           documents=documents,
                           status_filter=status_filter,
                           type_filter=type_filter)


@app.route('/documents/create', methods=['GET', 'POST'])
@login_required
def create_document():
    form = DocumentForm()

    if form.validate_on_submit():
        doc_number = f"{form.doc_type.data[:3].upper()}-{datetime.now().strftime('%Y%m%d%H%M%S')}"

        file_path = None
        if form.file.data:
            filename = secure_filename(form.file.data.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            form.file.data.save(file_path)

        doc = Document(
            doc_number=doc_number,
            title=form.title.data,
            doc_type=form.doc_type.data,
            description=form.description.data,
            amount=form.amount.data if form.amount.data else None,
            contractor=form.contractor.data,
            status='Черновик',
            file_path=file_path,
            created_by=current_user.id,
            doc_date=form.doc_date.data
        )

        db.session.add(doc)
        db.session.commit()
        flash('Документ успешно создан!', 'success')
        return redirect(url_for('view_document', id=doc.id))

    return render_template('documents/create.html', form=form)


@app.route('/documents/<int:id>')
@login_required
def view_document(id):
    doc = Document.query.get_or_404(id)
    comments = Comment.query.filter_by(document_id=id)\
        .order_by(Comment.created_at.desc()).all()

    approval_stages = ApprovalStage.query.filter_by(document_id=id)\
        .order_by(ApprovalStage.order).all()

    form = CommentForm()

    return render_template('documents/view.html',
                           doc=doc,
                           comments=comments,
                           approval_stages=approval_stages,
                           form=form)


@app.route('/documents/<int:id>/comment', methods=['POST'])
@login_required
def add_comment(id):
    form = CommentForm()

    if form.validate_on_submit():
        comment = Comment(
            document_id=id,
            author_id=current_user.id,
            text=form.text.data
        )
        db.session.add(comment)
        db.session.commit()
        flash('Комментарий добавлен', 'success')

    return redirect(url_for('view_document', id=id))


@app.route('/documents/<int:id>/approve', methods=['POST'])
@login_required
def approve_document(id):
    doc = Document.query.get_or_404(id)

    stage = ApprovalStage.query.filter_by(
        document_id=id,
        approver_id=current_user.id,
        status='Ожидает'
    ).first()

    if stage:
        action = request.form.get('action')
        comment = request.form.get('comment', '')

        if action == 'approve':
            stage.status = 'Согласован'
            stage.approved_at = datetime.utcnow()
            stage.comment = comment

            all_stages = ApprovalStage.query.filter_by(document_id=id).all()
            all_approved = all(s.status == 'Согласован' for s in all_stages)
            if all_approved:
                doc.status = 'Согласован'

            flash('Документ согласован', 'success')

        elif action == 'reject':
            stage.status = 'Отклонен'
            stage.approved_at = datetime.utcnow()
            stage.comment = comment
            doc.status = 'Отклонен'
            flash('Документ отклонен', 'warning')

        db.session.commit()

    return redirect(url_for('view_document', id=id))


@app.route('/notifications')
@login_required
def notifications():
    notifs = Notification.query.filter_by(recipient_id=current_user.id)\
        .order_by(Notification.created_at.desc()).all()

    for notif in notifs:
        if not notif.is_read:
            notif.is_read = True

    db.session.commit()

    return render_template('notifications.html', notifications=notifs)


@app.route('/reports')
@login_required
def reports():
    total_docs = Document.query.count()
    if total_docs == 0:
        total_docs_safe = 1
    else:
        total_docs_safe = total_docs

    docs_by_type = db.session.query(
        Document.doc_type,
        db.func.count(Document.id)
    ).group_by(Document.doc_type).all()

    docs_by_status = db.session.query(
        Document.status,
        db.func.count(Document.id)
    ).group_by(Document.status).all()

    today = datetime.now()
    first_day = today.replace(day=1)
    docs_this_month = Document.query.filter(
        Document.created_at >= first_day
    ).count()

    top_creators = db.session.query(
        User.full_name,
        db.func.count(Document.id).label('doc_count')
    ).join(Document).group_by(User.id).order_by(
        db.func.count(Document.id).desc()
    ).limit(5).all()

    return render_template('reports.html',
                           total_docs=total_docs,
                           total_docs_safe=total_docs_safe,
                           docs_by_type=dict(docs_by_type),
                           docs_by_status=dict(docs_by_status),
                           docs_this_month=docs_this_month,
                           top_creators=top_creators)


@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        current_user.full_name = request.form.get('full_name')
        current_user.position = request.form.get('position')
        current_user.department = request.form.get('department')

        new_password = request.form.get('new_password')
        if new_password and len(new_password) >= 6:
            current_user.password_hash = generate_password_hash(new_password)
            flash('Пароль успешно изменен', 'success')

        db.session.commit()
        flash('Настройки успешно сохранены', 'success')
        return redirect(url_for('settings'))

    return render_template('settings.html')


@app.route('/users')
@login_required
def users_list():
    if not current_user.is_admin():
        flash('Доступ запрещен. Только для администраторов.', 'danger')
        return redirect(url_for('index'))

    users = User.query.all()
    return render_template('users.html', users=users)


@app.route('/users/create', methods=['GET', 'POST'])
@login_required
def create_user():
    if not current_user.is_admin():
        flash('Доступ запрещен.', 'danger')
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        full_name = request.form.get('full_name')
        position = request.form.get('position')
        department = request.form.get('department')
        role = request.form.get('role')

        if User.query.filter_by(username=username).first():
            flash('Пользователь с таким именем уже существует', 'danger')
            return redirect(url_for('create_user'))

        new_user = User(
            username=username,
            password_hash=generate_password_hash(password),
            full_name=full_name,
            position=position,
            department=department,
            role=role,
            is_approver=(role in ['Администратор', 'Руководитель'])
        )

        db.session.add(new_user)
        db.session.commit()
        flash('Пользователь создан', 'success')
        return redirect(url_for('users_list'))

    return render_template('users_create.html')


@app.route('/uploads/<filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("База данных создана")
    app.run(debug=True)