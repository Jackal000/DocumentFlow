from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    position = db.Column(db.String(100))
    department = db.Column(db.String(100))
    role = db.Column(db.String(50), default='Сотрудник')
    is_approver = db.Column(db.Boolean, default=False)

    documents = db.relationship('Document', backref='creator', lazy=True)
    approvals = db.relationship('ApprovalStage', backref='approver', lazy=True)

    def has_role(self, role_name):
        return self.role == role_name

    def is_admin(self):
        return self.role == 'Администратор'

    def __repr__(self):
        return f'<User {self.username}>'


class Document(db.Model):
    __tablename__ = 'documents'

    id = db.Column(db.Integer, primary_key=True)
    doc_number = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(200), nullable=False)
    doc_type = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text)
    amount = db.Column(db.Float)
    contractor = db.Column(db.String(200))
    status = db.Column(db.String(50), default='Черновик')
    file_path = db.Column(db.String(300))
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    doc_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    approval_stages = db.relationship('ApprovalStage', backref='document', lazy=True, cascade='all, delete-orphan')
    comments = db.relationship('Comment', backref='document', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Document {self.doc_number}>'


class ApprovalStage(db.Model):
    __tablename__ = 'approval_stages'

    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'), nullable=False)
    approver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    order = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(50), default='Ожидает')
    comment = db.Column(db.Text)
    approved_at = db.Column(db.DateTime)

    def __repr__(self):
        return f'<ApprovalStage {self.id} for Document {self.document_id}>'


class Comment(db.Model):
    __tablename__ = 'comments'

    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship('User', backref='comments')

    def __repr__(self):
        return f'<Comment {self.id}>'


class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'))
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    recipient = db.relationship('User', backref='notifications')

    def __repr__(self):
        return f'<Notification {self.id}>'