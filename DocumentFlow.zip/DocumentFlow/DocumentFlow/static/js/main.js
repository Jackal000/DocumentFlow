// ==========================================
// DocumentFlow — Основной JavaScript
// АО ГринАтом / Система документооборота
// ==========================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DocumentFlow загружен');
    
    // Автоматическое скрытие alert-ов через 5 секунд
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // Подтверждение удаления
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Вы уверены, что хотите удалить этот документ?')) {
                e.preventDefault();
            }
        });
    });
    
    // Подсветка активного пункта меню
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.sidebar .nav-link');
    navLinks.forEach(function(link) {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
});