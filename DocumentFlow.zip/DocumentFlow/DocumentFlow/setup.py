import os
import shutil

def create_project_structure():
    """Создает полную структуру проекта DocumentFlow"""
    
    # Базовая директория
    base_dir = os.path.dirname(os.path.abspath(__file__))
    print(f"📁 Создание проекта в: {base_dir}\n")
    
    # Структура папок
    directories = [
        'static/css',
        'static/js',
        'static/images',
        'templates/documents',
        'templates/approvals',
        'uploads',
        'instance'
    ]
    
    # Создаем папки
    print("📂 Создание папок...")
    for directory in directories:
        path = os.path.join(base_dir, directory)
        os.makedirs(path, exist_ok=True)
        print(f"   ✓ {directory}")
    
    # Создаем файлы с кодом
    print("\n📄 Создание файлов...")
    
    # 1. requirements.txt
    with open(os.path.join(base_dir, 'requirements.txt'), 'w', encoding='utf-8') as f:
        f.write("""flask==2.3.0
flask-sqlalchemy==3.0.3
flask-login==0.6.2
flask-wtf==1.1.1
werkzeug==2.3.0
python-docx==0.8.11
""")
    print("   ✓ requirements.txt")
    
    # 2. .gitignore
    with open(os.path.join(base_dir, '.gitignore'), 'w', encoding='utf-8') as f:
        f.write("""__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
instance/
uploads/
*.db
*.sqlite
*.sqlite3
.DS_Store
.env
""")
    print("   ✓ .gitignore")
    
    # 3. config.py
    with open(os.path.join(base_dir, 'config.py'), 'w', encoding='utf-8') as f:
        f.write("""import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \\
        'sqlite:///' + os.path.join(BASE_DIR, 'instance', 'documents.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'txt'}
""")
    print("   ✓ config.py")
    
    # 4. models.py
    with open(os.path.join(base_dir, 'models.py'), 'w', encoding='utf-8') as f:
        f.write("""from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    position = db.Column(db.String(100))
    department = db.Column(db.String(100))
    is_approver = db.Column(db.Boolean, default=False)
    
    documents = db.relationship('Document', backref='creator', lazy=True)
    approvals = db.relationship('ApprovalStage', backref='approver', lazy=True)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Document(db.Model):
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    doc_number = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(200), nullable=False)
    doc_type = db.Column(db.String(50), nullable=False)  # Договор, Служебная записка, Письмо
    description = db.Column(db.Text)
    amount = db.Column(db.Float)
    contractor = db.Column(db.String(200))
    status = db.Column(db.String(50), default='Черновик')
    file_path = db.Column(db.String(300))
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    doc_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    approval_stages = db.relationship('ApprovalStage', backref='document', lazy=True, cascade='all, delete-orphan')
    comments = db.relationship('Comment', backref='document', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Document {self.doc_number}>'

class ApprovalStage(db.Model):
    __tablename__ = 'approval_stages'
    
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'), nullable=False)
    approver_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    order = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(50), default='Ожидает')  # Ожидает, Согласован, Отклонен
    comment = db.Column(db.Text)
    approved_at = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<ApprovalStage {self.id} for Document {self.document_id}>'

class Comment(db.Model):
    __tablename__ = 'comments'
    
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    text = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    author = db.relationship('User', backref='comments')
    
    def __repr__(self):
        return f'<Comment {self.id}>'

class Notification(db.Model):
    __tablename__ = 'notifications'
    
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'))
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    recipient = db.relationship('User', backref='notifications')
    
    def __repr__(self):
        return f'<Notification {self.id}>'
""")
    print("   ✓ models.py")
    
    print("\n✅ Базовая структура создана!")
    print("\n📝 Теперь создайте файл app.py (я дам его следующим шагом)")

if __name__ == '__main__':
    create_project_structure()