from app import app, db
from models import User, Document, ApprovalStage, Comment
from werkzeug.security import generate_password_hash
from datetime import datetime, date, timedelta
import random

def seed_database():
    """Заполняет базу данных тестовыми данными"""
    
    with app.app_context():
        db.create_all()
        print("✅ Таблицы базы данных успешно созданы/проверены!")
        
        print("🌱 Начинаем заполнение базы данных...")
        
        Comment.query.delete()
        ApprovalStage.query.delete()
        Document.query.delete()
        User.query.delete()
        db.session.commit()
        print("🧹 Старые данные удалены")
        
        print("👤 Создание пользователей...")
        
        admin = User(
            username='admin',
            password_hash=generate_password_hash('admin123'),
            full_name='Иванов Иван Иванович',
            position='Администратор системы',
            department='ИТ отдел',
            role='Администратор',
            is_approver=True
        )
        
        manager = User(
            username='manager',
            password_hash=generate_password_hash('manager123'),
            full_name='Петров Петр Петрович',
            position='Руководитель отдела',
            department='Финансовый отдел',
            role='Руководитель',
            is_approver=True
        )
        
        user = User(
            username='user',
            password_hash=generate_password_hash('user123'),
            full_name='Сидоров Сидор Сидорович',
            position='Специалист',
            department='Юридический отдел',
            role='Сотрудник',
            is_approver=False
        )
        
        db.session.add_all([admin, manager, user])
        db.session.commit()
        print("   ✓ Создано 3 пользователя")
        
        print("📄 Создание 15 документов...")
        
        documents_data = [
            {
                'doc_number': 'ДОГ-20260501001',
                'title': 'Договор поставки серверного оборудования',
                'doc_type': 'Договор',
                'description': 'Поставка серверов Dell PowerEdge для ЦОД',
                'amount': 2500000.00,
                'contractor': 'ООО "ТехноСервис"',
                'status': 'Согласован',
                'created_by': user.id,
                'doc_date': date(2026, 5, 1)
            },
            {
                'doc_number': 'ДОГ-20260505002',
                'title': 'Договор аренды офисных помещений',
                'doc_type': 'Договор',
                'description': 'Аренда офиса на 3 года',
                'amount': 1800000.00,
                'contractor': 'ООО "НедвижимостьПлюс"',
                'status': 'На согласовании',
                'created_by': user.id,
                'doc_date': date(2026, 5, 5)
            },
            {
                'doc_number': 'ДОГ-20260510003',
                'title': 'Договор на техническое обслуживание',
                'doc_type': 'Договор',
                'description': 'ТО инженерных систем здания',
                'amount': 450000.00,
                'contractor': 'АО "ИнжСервис"',
                'status': 'Черновик',
                'created_by': user.id,
                'doc_date': date(2026, 5, 10)
            },
            {
                'doc_number': 'СЗ-20260512001',
                'title': 'Служебная записка о командировке',
                'doc_type': 'Служебная записка',
                'description': 'Командировка в Москву для участия в конференции',
                'amount': None,
                'contractor': None,
                'status': 'Согласован',
                'created_by': user.id,
                'doc_date': date(2026, 5, 12)
            },
            {
                'doc_number': 'СЗ-20260515002',
                'title': 'Служебная записка о закупке оборудования',
                'doc_type': 'Служебная записка',
                'description': 'Закупка ноутбуков для новых сотрудников',
                'amount': None,
                'contractor': None,
                'status': 'На согласовании',
                'created_by': user.id,
                'doc_date': date(2026, 5, 15)
            },
            {
                'doc_number': 'СЗ-20260518003',
                'title': 'Служебная записка о премировании',
                'doc_type': 'Служебная записка',
                'description': 'Премирование сотрудников за выполнение плана',
                'amount': None,
                'contractor': None,
                'status': 'Отклонен',
                'created_by': manager.id,
                'doc_date': date(2026, 5, 18)
            },
            {
                'doc_number': 'ПИС-20260520001',
                'title': 'Письмо от контрагента о задержке поставки',
                'doc_type': 'Письмо',
                'description': 'Уведомление о переносе сроков поставки на 2 недели',
                'amount': None,
                'contractor': 'ООО "ТехноСервис"',
                'status': 'Согласован',
                'created_by': admin.id,
                'doc_date': date(2026, 5, 20)
            },
            {
                'doc_number': 'ПИС-20260522002',
                'title': 'Письмо-запрос коммерческого предложения',
                'doc_type': 'Письмо',
                'description': 'Запрос КП на поставку канцелярских товаров',
                'amount': None,
                'contractor': 'ООО "КанцТорг"',
                'status': 'Черновик',
                'created_by': user.id,
                'doc_date': date(2026, 5, 22)
            },
            {
                'doc_number': 'ПИС-20260525003',
                'title': 'Письмо о расторжении договора',
                'doc_type': 'Письмо',
                'description': 'Уведомление о расторжении договора №123',
                'amount': None,
                'contractor': 'ООО "СтарыйПартнер"',
                'status': 'На согласовании',
                'created_by': manager.id,
                'doc_date': date(2026, 5, 25)
            },
            {
                'doc_number': 'ДОГ-20260528004',
                'title': 'Договор на оказание консалтинговых услуг',
                'doc_type': 'Договор',
                'description': 'Консалтинг по оптимизации бизнес-процессов',
                'amount': 750000.00,
                'contractor': 'ООО "БизнесКонсалт"',
                'status': 'Согласован',
                'created_by': user.id,
                'doc_date': date(2026, 5, 28)
            },
            {
                'doc_number': 'СЗ-20260530004',
                'title': 'Служебная записка об отпуске',
                'doc_type': 'Служебная записка',
                'description': 'Заявление на ежегодный оплачиваемый отпуск',
                'amount': None,
                'contractor': None,
                'status': 'Согласован',
                'created_by': user.id,
                'doc_date': date(2026, 5, 30)
            },
            {
                'doc_number': 'ПИС-20260601004',
                'title': 'Письмо-претензия по качеству товара',
                'doc_type': 'Письмо',
                'description': 'Претензия по качеству поставленной продукции',
                'amount': None,
                'contractor': 'ООО "Поставщик"',
                'status': 'Отклонен',
                'created_by': manager.id,
                'doc_date': date(2026, 6, 1)
            },
            {
                'doc_number': 'ДОГ-20260605005',
                'title': 'Договор страхования имущества',
                'doc_type': 'Договор',
                'description': 'Страхование офисного имущества на 1 год',
                'amount': 120000.00,
                'contractor': 'АО "Страхование"',
                'status': 'Черновик',
                'created_by': user.id,
                'doc_date': date(2026, 6, 5)
            },
            {
                'doc_number': 'СЗ-20260608005',
                'title': 'Служебная записка о повышении квалификации',
                'doc_type': 'Служебная записка',
                'description': 'Направление на курсы повышения квалификации',
                'amount': None,
                'contractor': None,
                'status': 'На согласовании',
                'created_by': user.id,
                'doc_date': date(2026, 6, 8)
            },
            {
                'doc_number': 'ПИС-20260610005',
                'title': 'Письмо благодарности партнеру',
                'doc_type': 'Письмо',
                'description': 'Благодарственное письмо за сотрудничество',
                'amount': None,
                'contractor': 'ООО "НадежныйПартнер"',
                'status': 'Согласован',
                'created_by': admin.id,
                'doc_date': date(2026, 6, 10)
            }
        ]
        
        documents = []
        for doc_data in documents_data:
            doc = Document(**doc_data)
            documents.append(doc)
        
        db.session.add_all(documents)
        db.session.commit()
        print(f"   ✓ Создано {len(documents)} документов")
        
        print("✅ Создание маршрутов согласования...")
        
        for doc in documents[:5]:
            stage1 = ApprovalStage(
                document_id=doc.id,
                approver_id=manager.id,
                order=1,
                status='Согласован',
                comment='Согласовано',
                approved_at=datetime.utcnow()
            )
            stage2 = ApprovalStage(
                document_id=doc.id,
                approver_id=admin.id,
                order=2,
                status='Ожидает' if doc.status == 'На согласовании' else 'Согласован',
                comment='На рассмотрении' if doc.status == 'На согласовании' else 'Утверждено',
                approved_at=datetime.utcnow() if doc.status != 'На согласовании' else None
            )
            db.session.add_all([stage1, stage2])
        
        db.session.commit()
        print("   ✓ Созданы этапы согласования")
        
        print("💬 Создание комментариев...")
        
        comments_data = [
            (documents[0].id, user.id, 'Документ подготовлен. Прошу согласовать.'),
            (documents[0].id, manager.id, 'Финансовые условия приемлемы. Согласовываю.'),
            (documents[1].id, user.id, 'Необходимо срочное согласование'),
            (documents[5].id, manager.id, 'Отклонено: несоответствие бюджету'),
            (documents[6].id, admin.id, 'Получено, принято к сведению'),
        ]
        
        comments = []
        for doc_id, author_id, text in comments_data:
            comment = Comment(
                document_id=doc_id,
                author_id=author_id,
                text=text,
                created_at=datetime.utcnow()
            )
            comments.append(comment)
        
        db.session.add_all(comments)
        db.session.commit()
        print(f"   ✓ Создано {len(comments)} комментариев")
        
        print("\n🎉 База данных успешно заполнена!")
        print("\n📋 Данные для входа:")
        print("   🔹 Администратор: admin / admin123")
        print("   🔹 Руководитель: manager / manager123")
        print("   🔹 Пользователь: user / user123")

if __name__ == '__main__':
    seed_database()