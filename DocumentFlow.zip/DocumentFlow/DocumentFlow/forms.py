from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, BooleanField, TextAreaField, SelectField, FloatField, DateField
from wtforms.validators import DataRequired, Length, Optional, NumberRange
from datetime import date

class LoginForm(FlaskForm):
    """Форма входа в систему"""
    username = StringField('Имя пользователя', 
                          validators=[DataRequired(message='Введите имя пользователя')])
    password = PasswordField('Пароль', 
                            validators=[DataRequired(message='Введите пароль')])
    remember = BooleanField('Запомнить меня')

class DocumentForm(FlaskForm):
    """Форма создания документа"""
    title = StringField('Заголовок документа', 
                       validators=[
                           DataRequired(message='Введите заголовок'),
                           Length(max=200, message='Максимум 200 символов')
                       ])
    
    doc_type = SelectField('Тип документа', 
                          choices=[
                              ('Договор', 'Договор'),
                              ('Служебная записка', 'Служебная записка'),
                              ('Письмо', 'Письмо')
                          ],
                          validators=[DataRequired()])
    
    description = TextAreaField('Описание', 
                               validators=[
                                   Length(max=1000, message='Максимум 1000 символов')
                               ])
    
    amount = FloatField('Сумма (для договоров)', 
                       validators=[
                           Optional(),
                           NumberRange(min=0, message='Сумма не может быть отрицательной')
                       ])
    
    contractor = StringField('Контрагент', 
                            validators=[
                                Length(max=200, message='Максимум 200 символов')
                            ])
    
    doc_date = DateField('Дата документа', 
                        format='%Y-%m-%d',
                        default=date.today,
                        validators=[DataRequired(message='Укажите дату')])
    
    file = FileField('Прикрепить файл', 
                    validators=[
                        FileAllowed(['pdf', 'doc', 'docx', 'txt'], 
                                   'Разрешены только PDF, Word и текстовые файлы')
                    ])

class CommentForm(FlaskForm):
    """Форма добавления комментария"""
    text = TextAreaField('Комментарий', 
                        validators=[
                            DataRequired(message='Введите комментарий'),
                            Length(max=500, message='Максимум 500 символов')
                        ])